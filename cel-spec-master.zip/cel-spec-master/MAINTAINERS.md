# CEL Language Council

| Name            | Company      | Area of Expertise |
|-----------------|--------------|-------------------|
| Alfred Fuller   | Facebook     | cel-cpp, cel-spec |
| Jim Larson      | Google       | cel-go, cel-spec  |
| Matthais Blume  | Google       | cel-spec          |
| Tristan Swadell | Google       | cel-go, cel-spec  |

## Emeritus

* Sanjay Ghemawat (Google)
* Wolfgang Grieskamp (Facebook)
